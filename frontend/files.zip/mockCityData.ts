import type { District, CityBudget } from '../types/city';

export const cityBudget: CityBudget = {
  total: 500_000_000,
  spent: 0,
  currency: '₸',
};

export const districts: District[] = [
  {
    id: 'yesil',
    name: 'Есильский район',
    population: 412_000,
    metrics: { transport: 58, greenery: 41, social: 63, safety: 71, service: 66 },
  },
  {
    id: 'almaty',
    name: 'Алматинский район',
    population: 365_000,
    metrics: { transport: 47, greenery: 34, social: 55, safety: 60, service: 52 },
  },
  {
    id: 'saryarka',
    name: 'Сарыаркинский район',
    population: 398_000,
    metrics: { transport: 52, greenery: 39, social: 58, safety: 64, service: 57 },
  },
  {
    id: 'baikonyr',
    name: 'Байконурский район',
    population: 210_000,
    metrics: { transport: 61, greenery: 47, social: 49, safety: 68, service: 54 },
  },
];
