export type MetricKey = 'transport' | 'greenery' | 'social' | 'safety' | 'service';

export interface DistrictMetrics {
  transport: number; // 0-100, доступность и качество транспортной сети
  greenery: number; // 0-100, обеспеченность зелёными зонами
  social: number; // 0-100, обеспеченность соц. инфраструктурой
  safety: number; // 0-100, индекс безопасности
  service: number; // 0-100, качество городских сервисов
}

export interface District {
  id: string;
  name: string;
  population: number;
  metrics: DistrictMetrics;
}

export interface CityBudget {
  total: number;
  spent: number;
  currency: string;
}
